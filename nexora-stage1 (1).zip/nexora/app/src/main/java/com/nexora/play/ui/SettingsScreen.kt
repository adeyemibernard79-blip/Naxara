package com.nexora.play.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexora.play.AppViewModel

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val s by vm.settings.collectAsStateWithLifecycle()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium)
        Column(Modifier.fillMaxWidth().glass().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Streaming quality (used when cloud is set up)")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("480p", "720p", "1080p").forEach { q -> FilterChip(s.quality == q, { vm.setQuality(q) }, { Text(q) }) }
            }
            Text("Frame rate")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(30, 60).forEach { f -> FilterChip(s.fps == f, { vm.setFps(f) }, { Text("$f fps") }) }
            }
        }
        Column(Modifier.fillMaxWidth().glass().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Nintendo DS emulator")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(s.dsCore == "desmume", { vm.setDsCore("desmume") }, { Text("DeSmuME") })
                FilterChip(s.dsCore == "melonds", { vm.setDsCore("melonds") }, { Text("melonDS") })
            }
            Text("If a DS game shows a black screen, try the other one.", color = Cyan)
        }
        Column(Modifier.fillMaxWidth().glass().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("PSP performance mode")
                Switch(checked = s.pspFast, onCheckedChange = vm::setPspFast)
            }
            Text("Skips some graphics effects and drops frames when the phone can't keep up. Turn it off if PSP games look broken.", color = Cyan)
        }
        Column(Modifier.fillMaxWidth().glass().padding(16.dp)) {
            Text("On-screen controller opacity: ${(s.padOpacity * 100).toInt()}%")
            Slider(s.padOpacity, vm::setPadOpacity, valueRange = 0.2f..1f)
        }
        Column(Modifier.fillMaxWidth().glass().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("ROM folder")
            Text(s.romUri ?: "Not chosen (set it in Library)")
        }
    }
}
